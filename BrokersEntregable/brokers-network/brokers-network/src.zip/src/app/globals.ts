declare var Mercadopago: any

export const globals = {
    Mercadopago
}
