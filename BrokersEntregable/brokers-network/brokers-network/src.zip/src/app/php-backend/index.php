

<!-- Usar el login desde el backend para poder consumirlo -->

<!-- tenemos que importar los header del php para que nos pueda regresar la info -->

<!-- usar el proyecto de viras para la sesión -->

<!-- en los guards se controla la redireccion -->

<!-- syngenta inventarios server, aquí se enceuntra el server de inventarios -->

