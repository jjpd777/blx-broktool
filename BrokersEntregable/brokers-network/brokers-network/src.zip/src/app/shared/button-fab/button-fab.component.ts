import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-button-fab',
  templateUrl: './button-fab.component.html',
  styleUrls: ['./button-fab.component.scss'],
})
export class ButtonFabComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
