import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-registro',
  templateUrl: './menu-registro.component.html',
  styleUrls: ['./menu-registro.component.scss'],
})
export class MenuRegistroComponent implements OnInit {

  constructor() { }

  urlLogo = '/assets/images/logoB.png';

  ngOnInit() {}

}
